package com.example.themovizz;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.example.themovizz.Adapters.MovieListAdapter;
import com.example.themovizz.Api.Services.MoviesService;
import com.example.themovizz.Utils.MovieDetailsResultCallback;
import com.example.themovizz.Utils.MovieListResultCallback;
import com.example.themovizz.Api.models.Movie;
import com.example.themovizz.Api.models.SingleMovie;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private RecyclerView recyclerView;
    private MovieListAdapter movieAdapter;
    private MoviesService moviesService;
    private int currentPage = 1; // Initial page number
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        moviesService = new MoviesService();

        // Initialize RecyclerView and load the initial movies
        initDrawer();
        initRecyclerView();
        loadMovies(currentPage);
    }

    public void initDrawer() {
        drawerLayout = findViewById(R.id.drawerLayout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(
                this,
                drawerLayout,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close
        );

        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        NavigationView navigationView = findViewById(R.id.navigationView);
        navigationView.setNavigationItemSelectedListener(this);

        Menu menu = navigationView.getMenu();
        MenuItem moviesItem = menu.findItem(R.id.nav_movies);
        moviesItem.setChecked(true);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here
        int itemId = item.getItemId();

        currentPage = 0;

        if (itemId == R.id.nav_movies) {
            // Handle Movies click
            movieAdapter.clearAll();
            loadMovies(currentPage);
            return true;
        } else if (itemId == R.id.nav_series) {
            // Handle Series click
            movieAdapter.clearAll();
            loadSeries(currentPage);
            return true;
        }

        return false;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    private void initRecyclerView() {
        recyclerView = findViewById(R.id.recyclerView);
        movieAdapter = new MovieListAdapter(MainActivity.this, new ArrayList<>());
        recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 3));
        recyclerView.setAdapter(movieAdapter);

        // Add a scroll listener to detect when the user reaches the end of the list
        // Add a scroll listener to detect when the user reaches the end of the list
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                // Check if the user has reached the end of the list
                if (!recyclerView.canScrollVertically(1)) {
                    // Determine which category (movies or series) is currently selected
                    NavigationView navigationView = findViewById(R.id.navigationView);
                    MenuItem checkedItem = navigationView.getCheckedItem();

                    if (checkedItem != null) {
                        if (checkedItem.getItemId() == R.id.nav_movies) {
                            // Load more movies when the end is reached
                            loadMovies(++currentPage);
                        } else if (checkedItem.getItemId() == R.id.nav_series) {
                            // Load more series when the end is reached
                            loadSeries(++currentPage);
                        }
                        // Add more conditions for other menu items if needed
                    }
                }
            }
        });

    }

    private void loadMovies(int page) {
        moviesService.getMoviesResults(page, new MovieListResultCallback() {
            @Override
            public void onMoviesReceived(List<Movie> movies) {
                // Append the new movies to the existing list
                movieAdapter.addMovies(movies);
            }

            @Override
            public void onError(String errorMessage) {
                // Handle the error
                Log.e("MovieApiClient", errorMessage);
            }
        });
    }

    private void loadSeries(int page) {
        moviesService.getSeriesResults(page, new MovieListResultCallback() {
            @Override
            public void onMoviesReceived(List<Movie> movies) {
                // Append the new movies to the existing list
                movieAdapter.addMovies(movies);
            }

            @Override
            public void onError(String errorMessage) {
                // Handle the error
                Log.e("MovieApiClient", errorMessage);
            }
        });
    }
}
