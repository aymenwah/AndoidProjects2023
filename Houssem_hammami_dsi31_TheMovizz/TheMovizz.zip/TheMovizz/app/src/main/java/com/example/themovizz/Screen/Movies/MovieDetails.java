package com.example.themovizz.Screen.Movies;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.themovizz.Api.Services.MoviesService;
import com.example.themovizz.Api.models.Movie;
import com.example.themovizz.Api.models.SingleMovie;
import com.example.themovizz.R;
import com.example.themovizz.Utils.MovieDetailsResultCallback;
import com.squareup.picasso.Picasso;

public class MovieDetails extends AppCompatActivity {
    private MoviesService movies_service;
    private WebView youtubeWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);
        movies_service = new MoviesService();


        // Retrieve the Movie object from the Intent
        Intent intent = getIntent();
        if (intent != null) {
            Movie movie = (Movie) intent.getSerializableExtra("movie");

            if (movie != null) {
                // add movie attr from intent
                // Load backdrop image
                ImageView backdropImageView = findViewById(R.id.movie_backdrop);
                String backdropUrl = "https://image.tmdb.org/t/p/original/" + movie.getBackdropPath();
                Picasso.get().load(backdropUrl).into(backdropImageView);

                // Load poster image
                ImageView posterImageView = findViewById(R.id.movie_poster);
                String posterUrl = "https://image.tmdb.org/t/p/w500/" + movie.getPosterPath();
                Picasso.get().load(posterUrl).into(posterImageView);

                // Now you have the Movie object, you can use its data
                // For example, set the movie title in a TextView
                TextView titleTextView = findViewById(R.id.movie_title);
                String title = "";
                if(movie.getTitle() != null) {
                    title = movie.getTitle();
                } else {
                    title = movie.getName();
                }
                titleTextView.setText(title);

                TextView releaseDate = findViewById(R.id.movie_release_date);
                releaseDate.setText(movie.getReleaseDate());

                // Now you have the Movie object, you can use its data
                movies_service.getSingleMovieResults(movie.getId(), new MovieDetailsResultCallback() {
                    @SuppressLint("SetJavaScriptEnabled")
                    @Override
                    public void onMovieDetailsReceived(SingleMovie api_movie) {
                        TextView overview = findViewById(R.id.movie_overview);
                        overview.setText(api_movie.getOverview());

                        // add rating

                        RatingBar rating = findViewById(R.id.movie_rating);
                        rating.setRating((int) (api_movie.getVoteAverage() / 2));
                        youtubeWebView = findViewById(R.id.youtubeWebView);
                        // Enable JavaScript and set the video URL
                        // Get the YouTube video URL from your Movie object

                        // Enable JavaScript and set the video URL
                        String video = "<iframe width=\"100%\" height=\"100%\" src=\"https://www.youtube.com/embed/" + api_movie.getVideos().getResults().get(0).getKey() + "\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>";
                        youtubeWebView.loadData(video, "text/html","utf-8");
                        youtubeWebView.getSettings().setJavaScriptEnabled(true);
                        youtubeWebView.setWebChromeClient(new WebChromeClient());
                    }

                    @Override
                    public void onError(String errorMessage) {
                        // Handle the error
                        Log.e("MovieApiClient", errorMessage);
                    }
                });
            }
        }
    }
}