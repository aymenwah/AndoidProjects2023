package com.example.themovizz.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.themovizz.R;
import com.example.themovizz.Api.models.Movie;
import com.example.themovizz.Screen.Movies.MovieDetails;
import com.squareup.picasso.Picasso;

import java.util.List;

public class MovieListAdapter extends RecyclerView.Adapter<MovieListAdapter.MovieViewHolder> {

    private List<Movie> movies;
    private Context context;

    public MovieListAdapter(Context context, List<Movie> movies) {
        this.context = context;
        this.movies = movies;
    }

    @Override
    public MovieViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_movie, parent, false);
        return new MovieViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MovieViewHolder holder, int position) {
        Movie movie = movies.get(position);

        // Load movie data into views
        // fix serie name and movie title
        String title = "";
        if(movie.getTitle() != null) {
            title = movie.getTitle();
        } else {
            title = movie.getName();
        }

        holder.movieTitleTextView.setText(title);

        // Load movie poster using an image loading library (e.g., Picasso, Glide)
        // For simplicity, we use a placeholder image here
        String baseUrl = "https://image.tmdb.org/t/p/w500/";
        String posterPath = movie.getPosterPath(); // Assuming this is the image file name
        String fullUrl = baseUrl + posterPath;

        Picasso.get().load(fullUrl)
                .into(holder.moviePosterImageView);

        // Set click listener for the item
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle item click
                // Start MovieDetailsActivity and pass the movie data
                Intent intent = new Intent(context, MovieDetails.class);
                intent.putExtra("movie", movie); // Pass the whole Movie object
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return movies.size();
    }

    public void addMovies(List<Movie> newMovies) {
        movies.addAll(newMovies);
        notifyDataSetChanged();
    }

    public void clearAll() {
        movies.clear();
        notifyDataSetChanged();
    }

    public static class MovieViewHolder extends RecyclerView.ViewHolder {
        ImageView moviePosterImageView;
        TextView movieTitleTextView;

        public MovieViewHolder(View itemView) {
            super(itemView);
            moviePosterImageView = itemView.findViewById(R.id.moviePosterImageView);
            movieTitleTextView = itemView.findViewById(R.id.movieTitleTextView);
        }
    }
}

